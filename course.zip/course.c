/**
 * @file course.c
 * @date 2022-04-09
 * @brief Course library for managing course info, including definitions of the Course functions
 *
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * Enrolls a student in a course
 *
 * @param course a variable that is of type Course and has information about the course the student
 *               is enrolling in.
 * @param student a variable that is of type Student and has informaion about the student enrolling
 *                in the course.
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1)
  {
    // dynamically allocate 1 space of memory that is the same size of Student if the number of students in the course is 1
    course->students = calloc(1, sizeof(Student));
  }
  else
  {
    // dynamically reallocate memory to hold the number of students in the course. Important because if there is another student being enrolled, it needs to be allocated so that we can store it.
    course->students = realloc(course->students, course->total_students * sizeof(Student));
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * Prints the course information including the name, the course code, the total number of students
 * and prints all the information about all the students enrolled in the course.
 *
 * @param course a variable that is of type Course and has all information about the course that is
 *                going to be displayed.
 * @return nothing
 */
void print_course(Course *course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // prints all the students in the course and their respective information
  for (int i = 0; i < course->total_students; i++)
    print_student(&course->students[i]);
}

/**
 * Finds out which student in the course has the highest average and returns that student
 *
 * @param course a variable that is of type Course and has all information about the course and
 *                its students enrolled.
 * @return the student with the highest average that is type Student.
 */
Student *top_student(Course *course)
{
  if (course->total_students == 0)
    return NULL;

  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    // if the current student_average is greater than max_average, then the new max_average is the student_average
    if (student_average > max_average)
    {
      max_average = student_average;
      student = &course->students[i];
    }
  }

  return student;
}

/**
 * Finds out which students in the course are passing the course and returns a dynamically
 * allocated array called "passing" with all the students passing the course
 *
 * @param course a variable that is of type Course and has all information about the course and
 *                its students enrolled.
 * @param total_passing a pointer that is type int that stores the number of students that are
 *                      passing the course.
 * @return a dynamically allocated array that is of type Student with the information
 *         each of the students passing the course.
 */
Student *passing(Course *course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;

  // this for loop is to figure out how many students pass the course so that we can dynamically allocate the memory space needed for the passing array
  for (int i = 0; i < course->total_students; i++)
    if (average(&course->students[i]) >= 50)
      count++;

  passing = calloc(count, sizeof(Student));

  // Now we input the students who passed the course in the dynamically allocated array, passing
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++;
    }
  }

  *total_passing = count;

  return passing;
}