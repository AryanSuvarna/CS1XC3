/**
 * @mainpage Course and Student functions Documentation
 *
 * This course and student function demonstration shows how the functions in the course library and
 * student library work.
 *
 * @file main.c
 * @brief Runs the code for the course library and student library methods.
 * @date 2022-04-07
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * Creates a course with the course code, "MATH 101", enrolls 20 random students in the course
 * with random grades, displays the top student in the course and finally displays the number of
 * students passing the course and all the information that is associated with them. This is all
 * done with the assistance of the student library and the course library.
 *
 */

int main()
{
  srand((unsigned)time(NULL));

  // creation of the course, Basics of Mathematics along with its course code, MATH 101.
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // enrolls 20 students in the course
  for (int i = 0; i < 20; i++)
    enroll_student(MATH101, generate_random_student(8));

  print_course(MATH101);

  // prints the student with the highest average in the course
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // prints all the students' info who are passing the course (>= 50) and shows the number of students passing the course
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++)
    print_student(&passing_students[i]);

  return 0;
}