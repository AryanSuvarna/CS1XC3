/**
 * @file student.c
 * @date 2022-04-09
 * @brief Student library for managing student info, including definitions of the Student functions
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * Adds a grade to a students' list of grades
 *
 * @param student a variable that is of type Student and has all the informaion about the student
 *                enrolled in the course.
 * @param grade a variable that is of type double that stores the value of the grade that is going
 *              to be stored.
 * @return nothing
 */
void add_grade(Student *student, double grade)
{
  student->num_grades++;
  // dynamically allocate 1 space of memory that is the same size of a double if the number of grades in the course is 1
  if (student->num_grades == 1)
    student->grades = calloc(1, sizeof(double));
  else
  {
    // dynamically reallocate memory to hold the number of grades for the students. Important because if there is another grade being added for the student, it needs to be allocated so that we can store it.
    student->grades = realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * Calculates the average grade of a student
 *
 * @param student a variable that is of type Student and has all the informaion about the student
 *                enrolled in the course.
 * @return the average grade of the student that is of type double
 */
double average(Student *student)
{
  if (student->num_grades == 0)
    return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++)
    total += student->grades[i];
  // returns average grade
  return total / ((double)student->num_grades);
}

/**
 * Prints all the information of the student including the name, ID, grades and the average
 *
 * @param student a variable that is of type Student and has all the informaion about the student
 *                enrolled in the course.
 * @return nothing
 */
void print_student(Student *student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // prints all the student's grades
  for (int i = 0; i < student->num_grades; i++)
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * Generates a random student with a list of random grades and returns the newly created student.
 * First we generate the first and last name of student by selecting it from a preexisting list
 * of first and last names. Then a list of grades is generated which ranges from a grade of 25 to
 * 100.
 *
 * @param grades a variable that is of type int that stores the number of grades the student will
 *               receive.
 * @return a student of type Student that has the name a name and a list of grades
 */
Student *generate_random_student(int grades)
{
  char first_names[][24] =
      {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
       "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
       "Julie", "Omar", "Yousef", "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] =
      {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams",
       "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat",
       "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

  Student *new_student = calloc(1, sizeof(Student));

  // randomly create a students name from the first_names and last_names char arrays
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // The ID is created by grouping 10 char numbers. Essentially when we convert an integer to a char, we look at the ASCII table to see
  // what char the integer maps to. The integers 48 to 57 map to the char numbers 0-9. (Ex. the integer 48 ='0', integer 57 = '9'.)
  for (int i = 0; i < 10; i++)
    new_student->id[i] = (char)((rand() % 10) + 48);
  // end off ID with the null character since it is a char array
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++)
  {
    add_grade(new_student, (double)(25 + (rand() % 75)));
  }

  return new_student;
}