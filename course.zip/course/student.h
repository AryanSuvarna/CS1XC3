/**
 * @file student.h
 * @brief Student library for managing students, which includes the student type definition
 *        and all the Student functions.
 *
 */

/**
 * Student type that stores a student with the fields: first name,last name, student id, grades,
 * and the number of grades received.
 */
typedef struct _student
{
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades;
  int num_grades;
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student *generate_random_student(int grades);
